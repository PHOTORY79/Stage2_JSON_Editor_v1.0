import { useState } from 'react';
import { Copy, CheckCircle, ChevronDown, ChevronUp } from 'lucide-react';
import { Scene } from '../../types/stage1.types';
import { copyToClipboard, generateScenarioEditPrompt } from '../../utils/promptGenerator';

interface ScenarioViewProps {
  title: string;
  scenes: Scene[];
}

interface SceneCardProps {
  scene: Scene;
}

function SceneCard({ scene }: SceneCardProps) {
  const [isExpanded, setIsExpanded] = useState(false);
  const [modifiedText, setModifiedText] = useState('');
  const [userRequest, setUserRequest] = useState('');
  const [copySuccess, setCopySuccess] = useState<'text' | 'prompt' | null>(null);

  const handleCopyOriginal = async () => {
    const success = await copyToClipboard(scene.scenario_text);
    if (success) {
      setCopySuccess('text');
      setTimeout(() => setCopySuccess(null), 2000);
    }
  };

  const handleCopyPrompt = async () => {
    const prompt = generateScenarioEditPrompt(scene, scene.scenario_text, modifiedText, userRequest);
    const success = await copyToClipboard(prompt);
    if (success) {
      setCopySuccess('prompt');
      setTimeout(() => setCopySuccess(null), 2000);
    }
  };

  return (
    <div className="bg-bg-secondary border border-border-color rounded-xl overflow-hidden transition-all duration-300 hover:border-accent-purple/50">
      {/* 헤더 */}
      <button
        onClick={() => setIsExpanded(!isExpanded)}
        className="w-full flex items-center justify-between p-4 hover:bg-bg-tertiary transition-colors"
      >
        <div className="flex items-center gap-3">
          <span className="px-2.5 py-1 bg-accent-purple/20 text-accent-purple rounded-md text-sm font-mono font-semibold">
            {scene.scene_id}
          </span>
          <span className="text-text-secondary text-sm">
            Scene {scene.scene_number}
          </span>
          <span className="text-text-secondary/50 text-sm">
            • {scene.sequence_id}
          </span>
        </div>
        
        <div className="flex items-center gap-2">
          <button
            onClick={(e) => { e.stopPropagation(); handleCopyOriginal(); }}
            className={`p-2 rounded-lg transition-all duration-200
                       ${copySuccess === 'text' 
                         ? 'bg-accent-green text-white' 
                         : 'hover:bg-accent-purple/20 text-text-secondary hover:text-accent-purple'
                       }`}
            title="시나리오 복사"
          >
            {copySuccess === 'text' ? <CheckCircle className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
          </button>
          {isExpanded ? (
            <ChevronUp className="w-5 h-5 text-text-secondary" />
          ) : (
            <ChevronDown className="w-5 h-5 text-text-secondary" />
          )}
        </div>
      </button>

      {/* 미리보기 (접힌 상태) */}
      {!isExpanded && (
        <div className="px-4 pb-4">
          <p className="text-text-secondary text-sm line-clamp-2 whitespace-pre-wrap">
            {scene.scenario_text.slice(0, 150)}...
          </p>
        </div>
      )}

      {/* 확장된 컨텐츠 */}
      {isExpanded && (
        <div className="border-t border-border-color">
          {/* 2열 구조 */}
          <div className="grid grid-cols-1 lg:grid-cols-2 divide-y lg:divide-y-0 lg:divide-x divide-border-color">
            {/* 좌측: 원본 시나리오 */}
            <div className="p-4">
              <div className="flex items-center justify-between mb-3">
                <h4 className="text-sm font-semibold text-text-primary flex items-center gap-2">
                  📖 원본 시나리오
                </h4>
                <button
                  onClick={handleCopyOriginal}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs transition-all duration-200
                             ${copySuccess === 'text' 
                               ? 'bg-accent-green text-white' 
                               : 'bg-bg-tertiary hover:bg-accent-purple/20 text-text-secondary hover:text-accent-purple'
                             }`}
                >
                  {copySuccess === 'text' ? (
                    <>
                      <CheckCircle className="w-3 h-3" />
                      복사됨
                    </>
                  ) : (
                    <>
                      <Copy className="w-3 h-3" />
                      복사
                    </>
                  )}
                </button>
              </div>
              <div className="bg-bg-tertiary rounded-lg p-4 max-h-[400px] overflow-y-auto">
                <pre className="text-sm text-text-primary whitespace-pre-wrap font-sans leading-relaxed">
                  {scene.scenario_text}
                </pre>
              </div>
            </div>

            {/* 우측: 수정 시나리오 */}
            <div className="p-4">
              <h4 className="text-sm font-semibold text-text-primary mb-3 flex items-center gap-2">
                ✏️ 수정 시나리오
              </h4>
              <textarea
                value={modifiedText}
                onChange={(e) => setModifiedText(e.target.value)}
                placeholder="수정된 시나리오를 입력하세요..."
                className="w-full h-[280px] p-4 bg-bg-tertiary border border-border-color rounded-lg
                           text-sm text-text-primary resize-none
                           focus:outline-none focus:border-accent-purple focus:ring-1 focus:ring-accent-purple
                           placeholder:text-text-secondary/50"
              />
            </div>
          </div>

          {/* 수정 요청 및 프롬프트 생성 */}
          <div className="p-4 border-t border-border-color bg-bg-tertiary/50">
            <div className="flex flex-col lg:flex-row gap-4">
              <div className="flex-1">
                <label className="block text-xs font-medium text-text-secondary mb-2">
                  수정 요청사항 (선택)
                </label>
                <input
                  type="text"
                  value={userRequest}
                  onChange={(e) => setUserRequest(e.target.value)}
                  placeholder="예: 대사를 좀 더 감정적으로 수정해주세요"
                  className="w-full px-4 py-2.5 bg-bg-secondary border border-border-color rounded-lg
                             text-sm text-text-primary
                             focus:outline-none focus:border-accent-purple focus:ring-1 focus:ring-accent-purple
                             placeholder:text-text-secondary/50"
                />
              </div>
              <button
                onClick={handleCopyPrompt}
                className={`flex items-center justify-center gap-2 px-6 py-2.5 rounded-lg
                           transition-all duration-200 whitespace-nowrap self-end
                           ${copySuccess === 'prompt'
                             ? 'bg-accent-green text-white'
                             : 'bg-gradient-to-r from-accent-purple to-accent-purple-dark text-white hover:shadow-glow-purple'
                           }`}
              >
                {copySuccess === 'prompt' ? (
                  <>
                    <CheckCircle className="w-4 h-4" />
                    프롬프트 복사됨!
                  </>
                ) : (
                  <>
                    <Copy className="w-4 h-4" />
                    프롬프트 생성 + 복사
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export function ScenarioView({ title, scenes }: ScenarioViewProps) {
  if (!scenes || scenes.length === 0) {
    return (
      <div className="flex-1 flex items-center justify-center">
        <div className="text-center">
          <p className="text-text-secondary text-lg">시나리오가 없습니다</p>
          <p className="text-text-secondary/50 text-sm mt-2">Step 3 완료 후 표시됩니다</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 overflow-y-auto p-6">
      <div className="max-w-6xl mx-auto">
        {/* 헤더 */}
        <div className="mb-6">
          <h2 className="text-2xl font-bold text-text-primary mb-2">🎬 Scenario</h2>
          <p className="text-text-secondary">{title}</p>
          <p className="text-text-secondary/50 text-sm mt-1">{scenes.length}개 씬</p>
        </div>

        {/* 씬 목록 */}
        <div className="space-y-4">
          {scenes.map((scene) => (
            <SceneCard key={scene.scene_id} scene={scene} />
          ))}
        </div>
      </div>
    </div>
  );
}
