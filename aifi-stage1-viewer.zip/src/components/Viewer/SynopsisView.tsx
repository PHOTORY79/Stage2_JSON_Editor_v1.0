import { useState } from 'react';
import { Copy, CheckCircle } from 'lucide-react';
import { Synopsis } from '../../types/stage1.types';
import { copyToClipboard } from '../../utils/promptGenerator';

interface SynopsisViewProps {
  logline: string;
  synopsis: Synopsis;
}

export function SynopsisView({ logline, synopsis }: SynopsisViewProps) {
  const [copySuccess, setCopySuccess] = useState<string | null>(null);

  const handleCopy = async (text: string, key: string) => {
    const success = await copyToClipboard(text);
    if (success) {
      setCopySuccess(key);
      setTimeout(() => setCopySuccess(null), 2000);
    }
  };

  const handleCopyAll = async () => {
    const fullText = `로그라인:\n${logline}\n\nACT 1 - 발단:\n${synopsis.act1}\n\nACT 2 - 전개:\n${synopsis.act2}\n\nACT 3 - 결말:\n${synopsis.act3}`;
    await handleCopy(fullText, 'all');
  };

  return (
    <div className="flex-1 overflow-y-auto p-6">
      <div className="max-w-3xl mx-auto">
        {/* 헤더 */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h2 className="text-2xl font-bold text-text-primary mb-2">📖 Synopsis</h2>
            <p className="text-text-secondary">로그라인 및 3막 시놉시스</p>
          </div>
          <button
            onClick={handleCopyAll}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-all duration-200
                       ${copySuccess === 'all'
                         ? 'bg-accent-green text-white'
                         : 'bg-bg-tertiary hover:bg-accent-purple/20 text-text-secondary hover:text-accent-purple border border-border-color hover:border-accent-purple'
                       }`}
          >
            {copySuccess === 'all' ? (
              <>
                <CheckCircle className="w-4 h-4" />
                복사됨
              </>
            ) : (
              <>
                <Copy className="w-4 h-4" />
                전체 복사
              </>
            )}
          </button>
        </div>

        {/* 로그라인 */}
        <div className="bg-gradient-to-r from-accent-purple/10 to-transparent border border-accent-purple/30 rounded-xl p-6 mb-6">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-sm font-semibold text-accent-purple uppercase tracking-wider flex items-center gap-2">
              🎬 Logline
            </h3>
            <button
              onClick={() => handleCopy(logline, 'logline')}
              className={`p-2 rounded-lg transition-all duration-200
                         ${copySuccess === 'logline'
                           ? 'bg-accent-green text-white'
                           : 'hover:bg-accent-purple/20 text-text-secondary hover:text-accent-purple'
                         }`}
            >
              {copySuccess === 'logline' ? <CheckCircle className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
            </button>
          </div>
          <p className="text-lg text-text-primary leading-relaxed">
            {logline}
          </p>
        </div>

        {/* 3막 시놉시스 */}
        <div className="space-y-4">
          {[
            { key: 'act1', label: 'ACT 1', subtitle: '발단', content: synopsis.act1 },
            { key: 'act2', label: 'ACT 2', subtitle: '전개', content: synopsis.act2 },
            { key: 'act3', label: 'ACT 3', subtitle: '결말', content: synopsis.act3 },
          ].map(({ key, label, subtitle, content }) => (
            <div key={key} className="bg-bg-secondary border border-border-color rounded-xl p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-3">
                  <span className="px-3 py-1 bg-accent-purple/20 text-accent-purple rounded-lg text-sm font-semibold">
                    {label}
                  </span>
                  <span className="text-text-secondary">
                    {subtitle}
                  </span>
                </div>
                <button
                  onClick={() => handleCopy(content, key)}
                  className={`p-2 rounded-lg transition-all duration-200
                             ${copySuccess === key
                               ? 'bg-accent-green text-white'
                               : 'hover:bg-accent-purple/20 text-text-secondary hover:text-accent-purple'
                             }`}
                >
                  {copySuccess === key ? <CheckCircle className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                </button>
              </div>
              <p className="text-text-primary leading-relaxed whitespace-pre-wrap">
                {content}
              </p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
