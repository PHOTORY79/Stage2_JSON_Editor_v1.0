import { useState } from 'react';
import { Copy, CheckCircle, ChevronDown, ChevronUp } from 'lucide-react';
import { Treatment, Sequence } from '../../types/stage1.types';
import { copyToClipboard } from '../../utils/promptGenerator';

interface TreatmentViewProps {
  treatment: Treatment;
}

interface SequenceCardProps {
  sequence: Sequence;
  index: number;
}

function SequenceCard({ sequence, index }: SequenceCardProps) {
  const [isExpanded, setIsExpanded] = useState(index === 0);
  const [copySuccess, setCopySuccess] = useState(false);

  const handleCopy = async () => {
    const text = `${sequence.sequence_title}\n\n${sequence.content}`;
    const success = await copyToClipboard(text);
    if (success) {
      setCopySuccess(true);
      setTimeout(() => setCopySuccess(false), 2000);
    }
  };

  const actColors: Record<string, string> = {
    '1': 'bg-blue-500/20 text-blue-400',
    '2': 'bg-yellow-500/20 text-yellow-400',
    '3': 'bg-red-500/20 text-red-400',
  };

  const functionLabels: Record<string, string> = {
    exposition: '도입',
    rising_action: '상승',
    climax: '클라이맥스',
    falling_action: '하강',
    resolution: '해결',
  };

  return (
    <div className="bg-bg-secondary border border-border-color rounded-xl overflow-hidden transition-all duration-300 hover:border-accent-purple/50">
      {/* 헤더 */}
      <button
        onClick={() => setIsExpanded(!isExpanded)}
        className="w-full flex items-center justify-between p-4 hover:bg-bg-tertiary transition-colors"
      >
        <div className="flex items-center gap-3 flex-wrap">
          <span className="px-2.5 py-1 bg-accent-purple/20 text-accent-purple rounded-md text-sm font-mono font-semibold">
            {sequence.sequence_id}
          </span>
          <span className="text-text-primary font-medium">
            {sequence.sequence_title}
          </span>
          <div className="flex items-center gap-2">
            <span className={`px-2 py-0.5 rounded text-xs ${actColors[sequence.act] || 'bg-gray-500/20 text-gray-400'}`}>
              ACT {sequence.act}
            </span>
            <span className="px-2 py-0.5 bg-bg-tertiary text-text-secondary rounded text-xs">
              {functionLabels[sequence.dramatic_function] || sequence.dramatic_function}
            </span>
          </div>
        </div>
        
        <div className="flex items-center gap-2">
          <button
            onClick={(e) => { e.stopPropagation(); handleCopy(); }}
            className={`p-2 rounded-lg transition-all duration-200
                       ${copySuccess 
                         ? 'bg-accent-green text-white' 
                         : 'hover:bg-accent-purple/20 text-text-secondary hover:text-accent-purple'
                       }`}
            title="시퀀스 복사"
          >
            {copySuccess ? <CheckCircle className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
          </button>
          {isExpanded ? (
            <ChevronUp className="w-5 h-5 text-text-secondary" />
          ) : (
            <ChevronDown className="w-5 h-5 text-text-secondary" />
          )}
        </div>
      </button>

      {/* 미리보기 (접힌 상태) */}
      {!isExpanded && (
        <div className="px-4 pb-4">
          <p className="text-text-secondary text-sm line-clamp-2">
            {sequence.content.slice(0, 150)}...
          </p>
        </div>
      )}

      {/* 확장된 컨텐츠 */}
      {isExpanded && (
        <div className="border-t border-border-color p-4">
          <div className="bg-bg-tertiary rounded-lg p-4">
            <p className="text-text-primary leading-relaxed whitespace-pre-wrap">
              {sequence.content}
            </p>
          </div>
        </div>
      )}
    </div>
  );
}

export function TreatmentView({ treatment }: TreatmentViewProps) {
  const [copySuccess, setCopySuccess] = useState(false);

  const handleCopyAll = async () => {
    const fullText = treatment.sequences
      .map(seq => `[${seq.sequence_id}] ${seq.sequence_title}\n\n${seq.content}`)
      .join('\n\n---\n\n');
    
    const success = await copyToClipboard(fullText);
    if (success) {
      setCopySuccess(true);
      setTimeout(() => setCopySuccess(false), 2000);
    }
  };

  if (!treatment || !treatment.sequences || treatment.sequences.length === 0) {
    return (
      <div className="flex-1 flex items-center justify-center">
        <div className="text-center">
          <p className="text-text-secondary text-lg">트리트먼트가 없습니다</p>
          <p className="text-text-secondary/50 text-sm mt-2">Step 2 완료 후 표시됩니다</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 overflow-y-auto p-6">
      <div className="max-w-4xl mx-auto">
        {/* 헤더 */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-2xl font-bold text-text-primary mb-2">📝 Treatment</h2>
            <p className="text-text-secondary">{treatment.title}</p>
            <p className="text-text-secondary/50 text-sm mt-1">
              {treatment.structure} • {treatment.sequences.length}개 시퀀스
            </p>
          </div>
          <button
            onClick={handleCopyAll}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-all duration-200
                       ${copySuccess
                         ? 'bg-accent-green text-white'
                         : 'bg-bg-tertiary hover:bg-accent-purple/20 text-text-secondary hover:text-accent-purple border border-border-color hover:border-accent-purple'
                       }`}
          >
            {copySuccess ? (
              <>
                <CheckCircle className="w-4 h-4" />
                복사됨
              </>
            ) : (
              <>
                <Copy className="w-4 h-4" />
                전체 복사
              </>
            )}
          </button>
        </div>

        {/* 시퀀스 목록 */}
        <div className="space-y-4">
          {treatment.sequences.map((sequence, index) => (
            <SequenceCard key={sequence.sequence_id} sequence={sequence} index={index} />
          ))}
        </div>
      </div>
    </div>
  );
}
