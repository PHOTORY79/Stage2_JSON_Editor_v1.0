import { useState } from 'react';
import { Copy, CheckCircle, ChevronDown, ChevronUp, User, MapPin, Package } from 'lucide-react';
import { Character, Location, Prop, Block } from '../../types/stage1.types';
import { copyToClipboard, generateBlockEditPrompt } from '../../utils/promptGenerator';

type ItemType = 'character' | 'location' | 'prop';
type Item = Character | Location | Prop;

interface ConceptArtViewProps {
  type: ItemType;
  items: Item[];
}

interface BlockCardProps {
  type: ItemType;
  item: Item;
}

function formatBlocks(blocks: Block): string {
  return Object.entries(blocks)
    .map(([key, value]) => `${key}: ${value}`)
    .join('\n');
}

function BlockCard({ type, item }: BlockCardProps) {
  const [isExpanded, setIsExpanded] = useState(false);
  const [modifiedBlocks, setModifiedBlocks] = useState('');
  const [userRequest, setUserRequest] = useState('');
  const [copySuccess, setCopySuccess] = useState<'blocks' | 'prompt' | null>(null);

  const blocksText = formatBlocks(item.blocks);
  const blockCount = Object.keys(item.blocks).length;

  const handleCopyBlocks = async () => {
    const success = await copyToClipboard(blocksText);
    if (success) {
      setCopySuccess('blocks');
      setTimeout(() => setCopySuccess(null), 2000);
    }
  };

  const handleCopyPrompt = async () => {
    const prompt = generateBlockEditPrompt(type, item, item.blocks, modifiedBlocks, userRequest);
    const success = await copyToClipboard(prompt);
    if (success) {
      setCopySuccess('prompt');
      setTimeout(() => setCopySuccess(null), 2000);
    }
  };

  const getIcon = () => {
    switch (type) {
      case 'character': return <User className="w-4 h-4" />;
      case 'location': return <MapPin className="w-4 h-4" />;
      case 'prop': return <Package className="w-4 h-4" />;
    }
  };

  const getDetail = () => {
    if (type === 'character' && 'character_detail' in item) {
      return (item as Character).character_detail;
    }
    if (type === 'prop' && 'prop_detail' in item) {
      return (item as Prop).prop_detail;
    }
    return null;
  };

  const detail = getDetail();

  return (
    <div className="bg-bg-secondary border border-border-color rounded-xl overflow-hidden transition-all duration-300 hover:border-accent-purple/50">
      {/* 헤더 */}
      <button
        onClick={() => setIsExpanded(!isExpanded)}
        className="w-full flex items-center justify-between p-4 hover:bg-bg-tertiary transition-colors"
      >
        <div className="flex items-center gap-3">
          <span className="p-2 bg-accent-purple/20 text-accent-purple rounded-lg">
            {getIcon()}
          </span>
          <div className="text-left">
            <div className="flex items-center gap-2">
              <span className="font-mono text-sm text-accent-purple font-semibold">
                {item.id}
              </span>
              <span className="text-text-primary font-medium">
                {item.name}
              </span>
            </div>
            <p className="text-text-secondary text-xs mt-0.5">
              {blockCount}개 블록
            </p>
          </div>
        </div>
        
        <div className="flex items-center gap-2">
          <button
            onClick={(e) => { e.stopPropagation(); handleCopyBlocks(); }}
            className={`p-2 rounded-lg transition-all duration-200
                       ${copySuccess === 'blocks' 
                         ? 'bg-accent-green text-white' 
                         : 'hover:bg-accent-purple/20 text-text-secondary hover:text-accent-purple'
                       }`}
            title="블록 전체 복사"
          >
            {copySuccess === 'blocks' ? <CheckCircle className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
          </button>
          {isExpanded ? (
            <ChevronUp className="w-5 h-5 text-text-secondary" />
          ) : (
            <ChevronDown className="w-5 h-5 text-text-secondary" />
          )}
        </div>
      </button>

      {/* 상세 정보 미리보기 (접힌 상태) */}
      {!isExpanded && detail && (
        <div className="px-4 pb-4">
          <p className="text-text-secondary text-sm line-clamp-2">
            {detail.slice(0, 150)}...
          </p>
        </div>
      )}

      {/* 확장된 컨텐츠 */}
      {isExpanded && (
        <div className="border-t border-border-color">
          {/* 상세 정보 (있는 경우) */}
          {detail && (
            <div className="p-4 bg-bg-tertiary/30 border-b border-border-color">
              <p className="text-xs font-semibold text-text-secondary mb-2">
                {type === 'character' ? 'Character Detail' : 'Prop Detail'}
              </p>
              <p className="text-sm text-text-primary whitespace-pre-wrap">
                {detail}
              </p>
            </div>
          )}

          {/* Voice Style (캐릭터인 경우) */}
          {type === 'character' && 'voice_style' in item && (
            <div className="p-4 bg-bg-tertiary/30 border-b border-border-color">
              <p className="text-xs font-semibold text-text-secondary mb-2">Voice Style</p>
              <p className="text-sm text-text-primary">
                {(item as Character).voice_style}
              </p>
            </div>
          )}

          {/* 2열 구조: 블록 */}
          <div className="grid grid-cols-1 lg:grid-cols-2 divide-y lg:divide-y-0 lg:divide-x divide-border-color">
            {/* 좌측: 원본 블록 */}
            <div className="p-4">
              <div className="flex items-center justify-between mb-3">
                <h4 className="text-sm font-semibold text-text-primary flex items-center gap-2">
                  📖 원본 블록
                </h4>
                <button
                  onClick={handleCopyBlocks}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs transition-all duration-200
                             ${copySuccess === 'blocks' 
                               ? 'bg-accent-green text-white' 
                               : 'bg-bg-tertiary hover:bg-accent-purple/20 text-text-secondary hover:text-accent-purple'
                             }`}
                >
                  {copySuccess === 'blocks' ? (
                    <>
                      <CheckCircle className="w-3 h-3" />
                      복사됨
                    </>
                  ) : (
                    <>
                      <Copy className="w-3 h-3" />
                      전체 복사
                    </>
                  )}
                </button>
              </div>
              <div className="bg-bg-tertiary rounded-lg p-4 max-h-[400px] overflow-y-auto">
                <pre className="text-xs text-text-primary whitespace-pre-wrap font-mono leading-relaxed">
                  {blocksText}
                </pre>
              </div>
            </div>

            {/* 우측: 수정/번역 블록 */}
            <div className="p-4">
              <h4 className="text-sm font-semibold text-text-primary mb-3 flex items-center gap-2">
                ✏️ 수정 / 번역 블록
              </h4>
              <textarea
                value={modifiedBlocks}
                onChange={(e) => setModifiedBlocks(e.target.value)}
                placeholder="번역된 블록을 붙여넣거나 수정 내용을 입력하세요..."
                className="w-full h-[280px] p-4 bg-bg-tertiary border border-border-color rounded-lg
                           text-xs text-text-primary font-mono resize-none
                           focus:outline-none focus:border-accent-purple focus:ring-1 focus:ring-accent-purple
                           placeholder:text-text-secondary/50"
              />
            </div>
          </div>

          {/* 수정 요청 및 프롬프트 생성 */}
          <div className="p-4 border-t border-border-color bg-bg-tertiary/50">
            <div className="flex flex-col lg:flex-row gap-4">
              <div className="flex-1">
                <label className="block text-xs font-medium text-text-secondary mb-2">
                  수정 요청사항 (선택)
                </label>
                <input
                  type="text"
                  value={userRequest}
                  onChange={(e) => setUserRequest(e.target.value)}
                  placeholder="예: 캐릭터의 나이를 30대 후반으로 변경해주세요"
                  className="w-full px-4 py-2.5 bg-bg-secondary border border-border-color rounded-lg
                             text-sm text-text-primary
                             focus:outline-none focus:border-accent-purple focus:ring-1 focus:ring-accent-purple
                             placeholder:text-text-secondary/50"
                />
              </div>
              <button
                onClick={handleCopyPrompt}
                className={`flex items-center justify-center gap-2 px-6 py-2.5 rounded-lg
                           transition-all duration-200 whitespace-nowrap self-end
                           ${copySuccess === 'prompt'
                             ? 'bg-accent-green text-white'
                             : 'bg-gradient-to-r from-accent-purple to-accent-purple-dark text-white hover:shadow-glow-purple'
                           }`}
              >
                {copySuccess === 'prompt' ? (
                  <>
                    <CheckCircle className="w-4 h-4" />
                    프롬프트 복사됨!
                  </>
                ) : (
                  <>
                    <Copy className="w-4 h-4" />
                    프롬프트 생성 + 복사
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export function ConceptArtView({ type, items }: ConceptArtViewProps) {
  const typeInfo = {
    character: { icon: User, label: 'Characters', emoji: '👤' },
    location: { icon: MapPin, label: 'Locations', emoji: '📍' },
    prop: { icon: Package, label: 'Props', emoji: '📦' },
  }[type];

  if (!items || items.length === 0) {
    return (
      <div className="flex-1 flex items-center justify-center">
        <div className="text-center">
          <p className="text-text-secondary text-lg">{typeInfo.label}이(가) 없습니다</p>
          <p className="text-text-secondary/50 text-sm mt-2">Step 4 완료 후 표시됩니다</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 overflow-y-auto p-6">
      <div className="max-w-6xl mx-auto">
        {/* 헤더 */}
        <div className="mb-6">
          <h2 className="text-2xl font-bold text-text-primary mb-2">
            {typeInfo.emoji} {typeInfo.label}
          </h2>
          <p className="text-text-secondary">{items.length}개 항목</p>
        </div>

        {/* 아이템 목록 */}
        <div className="space-y-4">
          {items.map((item) => (
            <BlockCard key={item.id} type={type} item={item} />
          ))}
        </div>
      </div>
    </div>
  );
}
