import { FilmMetadata } from '../../types/stage1.types';

interface MetadataViewProps {
  filmId: string;
  currentStep: string;
  timestamp: string;
  metadata: FilmMetadata;
}

export function MetadataView({ filmId, currentStep, timestamp, metadata }: MetadataViewProps) {
  const stepLabels: Record<string, string> = {
    logline_synopsis_development: 'Step 1: 로그라인/시놉시스',
    treatment_expansion: 'Step 2: 트리트먼트',
    scenario_development: 'Step 3: 시나리오',
    concept_art_blocks_completed: 'Step 4: 컨셉아트 완료',
  };

  const formatTimestamp = (ts: string) => {
    try {
      return new Date(ts).toLocaleString('ko-KR');
    } catch {
      return ts;
    }
  };

  return (
    <div className="flex-1 overflow-y-auto p-6">
      <div className="max-w-3xl mx-auto">
        {/* 헤더 */}
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-text-primary mb-2">📋 Film Metadata</h2>
          <p className="text-text-secondary">프로젝트 기본 정보</p>
        </div>

        {/* 시스템 정보 */}
        <div className="bg-bg-secondary border border-border-color rounded-xl p-6 mb-6">
          <h3 className="text-sm font-semibold text-text-secondary uppercase tracking-wider mb-4">
            System Info
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <p className="text-xs text-text-secondary mb-1">Film ID</p>
              <p className="font-mono text-accent-purple font-semibold">{filmId}</p>
            </div>
            <div>
              <p className="text-xs text-text-secondary mb-1">Current Step</p>
              <p className="text-text-primary">
                <span className="px-2 py-1 bg-accent-purple/20 text-accent-purple rounded text-sm">
                  {stepLabels[currentStep] || currentStep}
                </span>
              </p>
            </div>
            <div>
              <p className="text-xs text-text-secondary mb-1">Timestamp</p>
              <p className="text-text-primary text-sm">{formatTimestamp(timestamp)}</p>
            </div>
          </div>
        </div>

        {/* 필름 메타데이터 */}
        <div className="bg-bg-secondary border border-border-color rounded-xl overflow-hidden">
          <div className="p-6 border-b border-border-color">
            <h3 className="text-sm font-semibold text-text-secondary uppercase tracking-wider">
              Film Details
            </h3>
          </div>
          
          <div className="divide-y divide-border-color">
            {[
              { label: 'Title', value: metadata.title_working, highlight: true },
              { label: 'Genre', value: metadata.genre },
              { label: 'Duration', value: `${metadata.duration_minutes} minutes` },
              { label: 'Style', value: metadata.style },
              { label: 'Artist', value: metadata.artist || '(none)', muted: !metadata.artist },
              { label: 'Medium', value: metadata.medium },
              { label: 'Era', value: metadata.era },
              { label: 'Aspect Ratio', value: metadata.aspect_ratio },
            ].map(({ label, value, highlight, muted }) => (
              <div key={label} className="flex items-center p-4 hover:bg-bg-tertiary/50 transition-colors">
                <span className="w-32 text-sm text-text-secondary">{label}</span>
                <span className={`flex-1 ${highlight ? 'text-lg font-semibold text-text-primary' : muted ? 'text-text-secondary/50 italic' : 'text-text-primary'}`}>
                  {value}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
