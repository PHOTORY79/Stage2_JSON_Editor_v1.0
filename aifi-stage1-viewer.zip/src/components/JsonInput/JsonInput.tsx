import { useState, useRef, useCallback } from 'react';
import { FileJson, ClipboardPaste, Sparkles } from 'lucide-react';

interface JsonInputProps { onJsonLoad: (json: string) => void; }

export function JsonInput({ onJsonLoad }: JsonInputProps) {
  const [isDragging, setIsDragging] = useState(false);
  const [showPasteModal, setShowPasteModal] = useState(false);
  const [pasteValue, setPasteValue] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const readFile = (file: File) => {
    if (file.size > 10 * 1024 * 1024) { alert('파일 크기는 10MB를 초과할 수 없습니다.'); return; }
    const reader = new FileReader();
    reader.onload = (e) => onJsonLoad(e.target?.result as string);
    reader.readAsText(file);
  };

  const loadExample = () => {
    const ex = {"film_id":"FILM_000001","current_step":"concept_art_blocks_completed","timestamp":"2025-01-17T13:00:00Z","film_metadata":{"title_working":"시간의 메시지","genre":"SF drama","duration_minutes":10,"style":"Photorealistic","artist":null,"medium":"Photography","era":"modern Seoul 2025","aspect_ratio":"16:9"},"current_work":{"logline":"미래의 자신으로부터 메시지를 받은 평범한 회사원이 가족을 구하기 위해 시간의 역설과 맞서는 이야기","synopsis":{"act1":"평범한 회사원 지은은 어느 날 스마트폰으로 1년 후 자신이 보낸 메시지를 받는다.","act2":"지은은 메시지를 바탕으로 미래를 바꾸려 노력하지만, 역설적 상황에 직면한다.","act3":"결국 지은은 현재를 충실히 살아가는 것이 진정한 답임을 깨닫는다."},"treatment":{"treatment_title":"시간의 메시지 - 트리트먼트","story_structure_type":"3막 구조","sequences":[{"sequence_id":"SEQ1","sequence_title":"미래로부터의 경고","narrative_function":"exposition","treatment_text":"지은이 카페에서 이상한 메시지를 받는다."}]},"scenario":{"scenario_title":"시간의 메시지 - 시나리오","scenes":[{"scene_number":1,"scene_id":"S01","sequence_id":"SEQ1","scenario_text":"INT. 카페 - 낮\n\n창가 테이블에 앉아 노트북으로 업무를 보는 지은(35).\n\n갑자기 스마트폰이 진동한다.\n\n          지은\n     (놀란 표정으로)\n  이게 뭐지?"}]}},"visual_blocks":{"characters":[{"id":"CHAR_001","name":"Jieun","blocks":{"1_STYLE":"Photorealistic portrait","2_ARTIST":"","3_MEDIUM":"Photography","4_GENRE":"SF drama","5_CHARACTER":"Jieun, Korean male 35 office worker","6_MOOD_PERSONALITY":"contemplative thoughtful anxious","7_ERA":"modern Seoul 2025","8_CAMERA":"Full Shot, front view, eye level","9_GAZE":"looking at camera","10_CHARACTER_SHEET":"","11_BODY_TYPE":"average height 175cm slim build","12_HAIR":"black short neat office style","13_FACE_SHAPE":"oval gentle features","14_FACIAL_FEATURES":"kind eyes worry lines","15_SKIN":"light warm tone","16_EXPRESSION":"worried contemplative","17_CLOTHING":"gray business suit white shirt","18_ACCESSORIES":"silver watch wedding ring","19_PROPS":"","20_POSE":"standing naturally","21_BACKGROUND":"white to gray gradient","22_LIGHTING":"soft studio lighting","23_CAMERA_TECH":"","24_QUALITY":"professional, Masterpiece","25_PARAMETER":"--ar 16:9 --style raw"},"character_detail":"contemplative thoughtful anxious, 175cm slim build, black short hair","voice_style":"30s male Korean calm thoughtful"}],"locations":[{"id":"LOC_001","name":"Cafe","blocks":{"1_STYLE":"Photorealistic","2_ARTIST":"","3_MEDIUM":"Photography","4_GENRE":"SF drama","5_LOCATION":"Cafe, modern coffee shop Seoul","6_ERA":"modern Seoul 2025","7_CAMERA":"Wide Shot, front view, eye level","8_LOCATION_SHEET":"","9_ATMOSPHERE":"calm cozy urban","10_COLOR_TONE":"warm browns creams","11_SCALE":"medium sized cafe","12_ARCHITECTURE":"modern minimalist","13_MATERIAL":"wood glass concrete","14_OBJECT":"coffee cups laptop plants","15_WEATHER":"Clear","16_NATURAL_LIGHT":"afternoon sunlight windows","17_ARTIFICIAL_LIGHT":"warm pendant lights","18_LIGHTING":"soft natural motivated","19_FOREGROUND":"coffee table cups","20_MIDGROUND":"seating area customers","21_BACKGROUND":"counter barista window","22_LEFT_SIDE":"bookshelf plants","23_RIGHT_SIDE":"large windows street view","24_CEILING/SKY":"exposed ceiling industrial","25_FLOOR/GROUND":"polished concrete","26_CAMERA_TECH":"","27_QUALITY":"professional, Masterpiece","28_PARAMETER":"--ar 16:9 --style raw"}}],"props":[{"id":"PROP_001","name":"Smartphone","blocks":{"1_STYLE":"Photorealistic","2_ARTIST":"","3_MEDIUM":"Photography","4_GENRE":"SF drama","5_ITEM_NAME":"Smartphone, latest model","6_ERA":"modern Seoul 2025","7_CAMERA":"Medium Close-up Shot, 45 degree","8_ITEM_SHEET":"","9_CATEGORY":"electronic device","10_MATERIAL":"glass aluminum","11_COLOR":"midnight black","12_SIZE":"6.5 inch screen","13_CONDITION":"new pristine","14_DETAILS":"edge display triple camera","15_FUNCTIONALITY":"messaging notification","16_SPECIAL_FEATURES":"blue glow message","17_LIGHTING":"soft studio lighting","18_BACKGROUND":"white to gray gradient","19_CAMERA_TECH":"","20_QUALITY":"professional, Masterpiece","21_PARAMETER":"--ar 16:9 --style raw"},"prop_detail":"glass aluminum, midnight black, 6.5 inch"}]}};
    onJsonLoad(JSON.stringify(ex, null, 2));
  };

  return (
    <>
      <div className="flex-1 flex items-center justify-center p-8">
        <div className="w-full max-w-lg">
          <div onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }} onDragLeave={(e) => { e.preventDefault(); setIsDragging(false); }}
            onDrop={(e) => { e.preventDefault(); setIsDragging(false); const f = e.dataTransfer.files[0]; if (f) readFile(f); }}
            onClick={() => fileInputRef.current?.click()}
            className={`relative border-2 border-dashed rounded-2xl p-12 text-center transition-all duration-300 cursor-pointer ${isDragging ? 'border-accent-purple bg-accent-purple/10 scale-[1.02]' : 'border-border-color hover:border-accent-purple/50 hover:bg-bg-secondary'}`}>
            <input ref={fileInputRef} type="file" accept=".json" onChange={(e) => { const f = e.target.files?.[0]; if (f) readFile(f); }} className="hidden" />
            <div className={`w-16 h-16 mx-auto mb-6 rounded-2xl flex items-center justify-center transition-all duration-300 ${isDragging ? 'bg-accent-purple text-white' : 'bg-bg-tertiary text-text-secondary'}`}>
              <FileJson className="w-8 h-8" />
            </div>
            <h3 className="text-lg font-semibold text-white mb-2">Drop JSON file here</h3>
            <p className="text-sm text-text-secondary mb-4">or click to browse files</p>
            <p className="text-xs text-text-secondary/60">Maximum file size: 10MB</p>
          </div>
          <div className="flex items-center gap-4 my-6"><div className="flex-1 h-px bg-border-color"></div><span className="text-sm text-text-secondary">or</span><div className="flex-1 h-px bg-border-color"></div></div>
          <div className="flex gap-3">
            <button onClick={() => setShowPasteModal(true)} className="flex-1 flex items-center justify-center gap-2 py-3 px-4 rounded-xl border border-border-color text-text-secondary hover:border-accent-purple hover:text-white transition-all"><ClipboardPaste className="w-4 h-4" /><span className="font-medium">Paste JSON</span></button>
            <button onClick={loadExample} className="flex-1 flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-gradient-to-r from-accent-purple to-accent-purple-dark text-white hover:shadow-glow-purple transition-all"><Sparkles className="w-4 h-4" /><span className="font-medium">Load Example</span></button>
          </div>
        </div>
      </div>
      {showPasteModal && (
        <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 p-4">
          <div className="bg-bg-secondary rounded-2xl w-full max-w-2xl max-h-[80vh] flex flex-col animate-fadeIn">
            <div className="p-6 border-b border-border-color"><h2 className="text-xl font-semibold text-white">Paste JSON</h2><p className="text-sm text-text-secondary mt-1">Stage 1 JSON 데이터를 붙여넣으세요</p></div>
            <div className="flex-1 p-6"><textarea value={pasteValue} onChange={(e) => setPasteValue(e.target.value)} placeholder='{"film_id": "FILM_000001", ...}' className="w-full h-80 bg-bg-primary border border-border-color rounded-xl p-4 text-white font-mono text-sm resize-none focus:border-accent-purple focus:outline-none" autoFocus /></div>
            <div className="p-6 border-t border-border-color flex justify-end gap-3">
              <button onClick={() => { setShowPasteModal(false); setPasteValue(''); }} className="px-6 py-2.5 rounded-lg border border-border-color text-text-secondary hover:text-white hover:border-accent-purple transition-all">Cancel</button>
              <button onClick={() => { if (pasteValue.trim()) { onJsonLoad(pasteValue); setShowPasteModal(false); setPasteValue(''); } }} disabled={!pasteValue.trim()} className={`px-6 py-2.5 rounded-lg font-medium transition-all ${pasteValue.trim() ? 'bg-gradient-to-r from-accent-purple to-accent-purple-dark text-white hover:shadow-glow-purple' : 'bg-bg-tertiary text-text-secondary/50 cursor-not-allowed'}`}>Load JSON</button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
