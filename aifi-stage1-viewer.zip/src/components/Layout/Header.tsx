import { Upload, RotateCcw, Download, FileJson } from 'lucide-react';

interface HeaderProps {
  onUpload: () => void;
  onReset: () => void;
  onDownload: () => void;
  hasData: boolean;
  fileName?: string;
}

export function Header({ onUpload, onReset, onDownload, hasData, fileName }: HeaderProps) {
  return (
    <header className="h-16 bg-bg-secondary border-b border-border-color flex items-center justify-between px-6">
      {/* 로고 영역 */}
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 bg-gradient-to-br from-accent-purple to-accent-purple-dark rounded-lg flex items-center justify-center shadow-glow-purple">
          <FileJson className="w-5 h-5 text-white" />
        </div>
        <div>
          <h1 className="text-lg font-semibold text-text-primary tracking-tight">
            AIFI Stage 1 Viewer
          </h1>
          {fileName && (
            <p className="text-xs text-text-secondary truncate max-w-[200px]">
              {fileName}
            </p>
          )}
        </div>
      </div>

      {/* 버튼 영역 */}
      <div className="flex items-center gap-2">
        <button
          onClick={onUpload}
          className="flex items-center gap-2 px-4 py-2 bg-bg-tertiary hover:bg-accent-purple/20 
                     text-text-primary rounded-lg transition-all duration-200 
                     border border-border-color hover:border-accent-purple
                     hover:shadow-glow-purple/30"
        >
          <Upload className="w-4 h-4" />
          <span className="text-sm font-medium">Upload</span>
        </button>

        <button
          onClick={onReset}
          disabled={!hasData}
          className="flex items-center gap-2 px-4 py-2 bg-bg-tertiary 
                     text-text-primary rounded-lg transition-all duration-200 
                     border border-border-color
                     hover:bg-accent-red/20 hover:border-accent-red hover:shadow-glow-red/30
                     disabled:opacity-40 disabled:cursor-not-allowed disabled:hover:bg-bg-tertiary
                     disabled:hover:border-border-color disabled:hover:shadow-none"
          title="모든 데이터 초기화"
        >
          <RotateCcw className="w-4 h-4" />
          <span className="text-sm font-medium">Reset</span>
        </button>

        <button
          onClick={onDownload}
          disabled={!hasData}
          className="flex items-center gap-2 px-4 py-2 
                     bg-gradient-to-r from-accent-purple to-accent-purple-dark
                     text-white rounded-lg transition-all duration-200 
                     hover:shadow-glow-purple
                     disabled:opacity-40 disabled:cursor-not-allowed 
                     disabled:from-bg-tertiary disabled:to-bg-tertiary
                     disabled:hover:shadow-none"
        >
          <Download className="w-4 h-4" />
          <span className="text-sm font-medium">Save JSON</span>
        </button>
      </div>
    </header>
  );
}
