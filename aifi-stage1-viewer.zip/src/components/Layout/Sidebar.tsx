import { 
  FileText, 
  BookOpen, 
  List, 
  Film, 
  Users, 
  MapPin, 
  Box,
  AlertTriangle,
  CheckCircle,
  XCircle
} from 'lucide-react';
import { ActiveSection, ValidationError } from '../../types/stage1.types';

interface SidebarProps {
  activeSection: ActiveSection;
  onSectionChange: (section: ActiveSection) => void;
  enabledSections: ActiveSection[];
  errors: ValidationError[];
}

const sections: { id: ActiveSection; label: string; icon: React.ElementType }[] = [
  { id: 'metadata', label: 'Metadata', icon: FileText },
  { id: 'synopsis', label: 'Synopsis', icon: BookOpen },
  { id: 'treatment', label: 'Treatment', icon: List },
  { id: 'scenario', label: 'Scenario', icon: Film },
  { id: 'characters', label: 'Characters', icon: Users },
  { id: 'locations', label: 'Locations', icon: MapPin },
  { id: 'props', label: 'Props', icon: Box },
];

export function Sidebar({ activeSection, onSectionChange, enabledSections, errors }: SidebarProps) {
  const getErrorCount = (section: ActiveSection): { errors: number; warnings: number } => {
    const sectionPaths: Record<ActiveSection, string[]> = {
      metadata: ['film_id', 'film_metadata'],
      synopsis: ['current_work.logline', 'current_work.synopsis'],
      treatment: ['current_work.treatment'],
      scenario: ['current_work.scenario'],
      characters: ['visual_blocks.characters'],
      locations: ['visual_blocks.locations'],
      props: ['visual_blocks.props'],
    };

    const paths = sectionPaths[section];
    const sectionErrors = errors.filter(e => 
      paths.some(p => e.path?.startsWith(p))
    );

    return {
      errors: sectionErrors.filter(e => e.severity === 'error').length,
      warnings: sectionErrors.filter(e => e.severity === 'warning').length,
    };
  };

  return (
    <aside className="w-56 bg-bg-secondary border-r border-border-color flex flex-col">
      <nav className="flex-1 p-3 space-y-1">
        <p className="text-xs font-semibold text-text-secondary uppercase tracking-wider px-3 mb-3">
          Sections
        </p>
        
        {sections.map(({ id, label, icon: Icon }) => {
          const isEnabled = enabledSections.includes(id);
          const isActive = activeSection === id;
          const { errors: errorCount, warnings: warningCount } = getErrorCount(id);

          return (
            <button
              key={id}
              onClick={() => isEnabled && onSectionChange(id)}
              disabled={!isEnabled}
              className={`
                w-full flex items-center gap-3 px-3 py-2.5 rounded-lg
                transition-all duration-200 group relative
                ${isActive 
                  ? 'bg-accent-purple/20 text-accent-purple border-l-2 border-accent-purple' 
                  : isEnabled
                    ? 'text-text-secondary hover:bg-bg-tertiary hover:text-text-primary'
                    : 'text-text-secondary/40 cursor-not-allowed'
                }
              `}
            >
              <Icon className={`w-4 h-4 ${isActive ? 'text-accent-purple' : ''}`} />
              <span className="text-sm font-medium flex-1 text-left">{label}</span>
              
              {isEnabled && (errorCount > 0 || warningCount > 0) && (
                <div className="flex items-center gap-1">
                  {errorCount > 0 && (
                    <span className="flex items-center gap-0.5 text-xs bg-accent-red/20 text-accent-red px-1.5 py-0.5 rounded">
                      <XCircle className="w-3 h-3" />
                      {errorCount}
                    </span>
                  )}
                  {warningCount > 0 && (
                    <span className="flex items-center gap-0.5 text-xs bg-yellow-500/20 text-yellow-500 px-1.5 py-0.5 rounded">
                      <AlertTriangle className="w-3 h-3" />
                      {warningCount}
                    </span>
                  )}
                </div>
              )}
              
              {isEnabled && errorCount === 0 && warningCount === 0 && (
                <CheckCircle className="w-4 h-4 text-accent-green opacity-0 group-hover:opacity-100 transition-opacity" />
              )}

              {!isEnabled && (
                <span className="text-xs text-text-secondary/40">미완성</span>
              )}
            </button>
          );
        })}
      </nav>

      <div className="p-3 border-t border-border-color">
        <div className="bg-bg-tertiary rounded-lg p-3">
          <p className="text-xs font-semibold text-text-secondary mb-2">검증 요약</p>
          <div className="flex items-center justify-between text-sm">
            <span className="flex items-center gap-1.5 text-accent-red">
              <XCircle className="w-4 h-4" />
              {errors.filter(e => e.severity === 'error').length} 오류
            </span>
            <span className="flex items-center gap-1.5 text-yellow-500">
              <AlertTriangle className="w-4 h-4" />
              {errors.filter(e => e.severity === 'warning').length} 경고
            </span>
          </div>
        </div>
      </div>
    </aside>
  );
}
