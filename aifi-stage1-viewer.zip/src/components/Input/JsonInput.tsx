import { useState, useRef, useCallback } from 'react';
import { Upload, FileJson, AlertCircle, CheckCircle, Copy, Sparkles } from 'lucide-react';
import { ValidationError } from '../../types/stage1.types';
import { copyToClipboard, generateSyntaxErrorPrompt } from '../../utils/promptGenerator';

interface JsonInputProps {
  onJsonParsed: (json: string) => void;
  errors: ValidationError[];
  rawJson: string;
  autoFixedCount: number;
}

export function JsonInput({ onJsonParsed, errors, rawJson, autoFixedCount }: JsonInputProps) {
  const [isDragging, setIsDragging] = useState(false);
  const [inputMode, setInputMode] = useState<'drop' | 'paste' | 'edit'>('drop');
  const [editableJson, setEditableJson] = useState('');
  const [copySuccess, setCopySuccess] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const syntaxErrors = errors.filter(e => e.level === 'syntax' && e.severity === 'error');
  const hasSyntaxError = syntaxErrors.length > 0;

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    
    const file = e.dataTransfer.files[0];
    if (file && file.type === 'application/json') {
      readFile(file);
    }
  }, []);

  const handleFileSelect = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      readFile(file);
    }
  }, []);

  const readFile = (file: File) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const content = e.target?.result as string;
      setEditableJson(content);
      onJsonParsed(content);
    };
    reader.readAsText(file);
  };

  const handlePaste = () => {
    setInputMode('paste');
  };

  const handleTextSubmit = () => {
    if (editableJson.trim()) {
      onJsonParsed(editableJson);
    }
  };

  const handleCopyErrorPrompt = async () => {
    const prompt = generateSyntaxErrorPrompt(syntaxErrors, rawJson);
    const success = await copyToClipboard(prompt);
    if (success) {
      setCopySuccess(true);
      setTimeout(() => setCopySuccess(false), 2000);
    }
  };

  // 드롭 영역 (초기 상태)
  if (inputMode === 'drop' && !rawJson) {
    return (
      <div className="flex-1 flex items-center justify-center p-8">
        <div
          className={`
            w-full max-w-2xl p-12 rounded-2xl border-2 border-dashed
            transition-all duration-300 text-center
            ${isDragging 
              ? 'border-accent-purple bg-accent-purple/10 shadow-glow-purple' 
              : 'border-border-color hover:border-accent-purple/50 bg-bg-secondary'
            }
          `}
          onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
          onDragLeave={() => setIsDragging(false)}
          onDrop={handleDrop}
        >
          <div className="flex flex-col items-center gap-6">
            <div className={`
              w-20 h-20 rounded-2xl flex items-center justify-center
              transition-all duration-300
              ${isDragging 
                ? 'bg-accent-purple shadow-glow-purple' 
                : 'bg-bg-tertiary'
              }
            `}>
              <FileJson className={`w-10 h-10 ${isDragging ? 'text-white' : 'text-accent-purple'}`} />
            </div>
            
            <div>
              <p className="text-xl font-semibold text-text-primary mb-2">
                Drop JSON file here
              </p>
              <p className="text-text-secondary">
                or use the buttons below
              </p>
            </div>

            <div className="flex items-center gap-4">
              <button
                onClick={() => fileInputRef.current?.click()}
                className="flex items-center gap-2 px-6 py-3 bg-accent-purple hover:bg-accent-purple-dark
                           text-white rounded-lg transition-all duration-200 hover:shadow-glow-purple"
              >
                <Upload className="w-4 h-4" />
                Browse Files
              </button>
              
              <span className="text-text-secondary">or</span>
              
              <button
                onClick={handlePaste}
                className="flex items-center gap-2 px-6 py-3 bg-bg-tertiary hover:bg-accent-purple/20
                           text-text-primary rounded-lg transition-all duration-200 
                           border border-border-color hover:border-accent-purple"
              >
                Paste JSON
              </button>
            </div>

            <input
              ref={fileInputRef}
              type="file"
              accept=".json"
              onChange={handleFileSelect}
              className="hidden"
            />
          </div>
        </div>
      </div>
    );
  }

  // 텍스트 입력 모드 또는 오류 편집 모드
  return (
    <div className="flex-1 flex flex-col p-6 gap-4">
      {/* 자동 수정 성공 알림 */}
      {autoFixedCount > 0 && !hasSyntaxError && (
        <div className="flex items-center gap-3 p-4 bg-accent-green/10 border border-accent-green/30 rounded-lg">
          <Sparkles className="w-5 h-5 text-accent-green" />
          <span className="text-accent-green">
            {autoFixedCount}개의 오류가 자동 수정되었습니다.
          </span>
        </div>
      )}

      {/* 문법 오류 패널 */}
      {hasSyntaxError && (
        <div className="bg-accent-red/10 border border-accent-red/30 rounded-lg p-4">
          <div className="flex items-start gap-3 mb-4">
            <AlertCircle className="w-5 h-5 text-accent-red flex-shrink-0 mt-0.5" />
            <div className="flex-1">
              <p className="font-semibold text-accent-red mb-2">
                자동 수정 불가 오류 {syntaxErrors.length}건
              </p>
              <ul className="space-y-1 text-sm text-text-secondary">
                {syntaxErrors.map((err, i) => (
                  <li key={i}>
                    {err.line ? `Line ${err.line}: ` : ''}{err.message}
                  </li>
                ))}
              </ul>
            </div>
          </div>
          
          <div className="flex items-center gap-3">
            <button
              onClick={() => setInputMode('edit')}
              className="flex items-center gap-2 px-4 py-2 bg-bg-tertiary hover:bg-accent-purple/20
                         text-text-primary rounded-lg transition-all duration-200 
                         border border-border-color hover:border-accent-purple text-sm"
            >
              ✏️ 직접 수정
            </button>
            <button
              onClick={handleCopyErrorPrompt}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-all duration-200 text-sm
                         ${copySuccess 
                           ? 'bg-accent-green text-white' 
                           : 'bg-accent-purple hover:bg-accent-purple-dark text-white hover:shadow-glow-purple'
                         }`}
            >
              {copySuccess ? (
                <>
                  <CheckCircle className="w-4 h-4" />
                  복사됨!
                </>
              ) : (
                <>
                  <Copy className="w-4 h-4" />
                  오류 프롬프트 복사
                </>
              )}
            </button>
          </div>
        </div>
      )}

      {/* JSON 에디터 */}
      {(inputMode === 'paste' || inputMode === 'edit' || hasSyntaxError) && (
        <div className="flex-1 flex flex-col gap-4">
          <div className="flex items-center justify-between">
            <p className="text-sm font-medium text-text-secondary">
              {hasSyntaxError ? 'JSON 수정' : 'JSON 입력'}
            </p>
            <button
              onClick={handleTextSubmit}
              className="flex items-center gap-2 px-4 py-2 bg-accent-purple hover:bg-accent-purple-dark
                         text-white rounded-lg transition-all duration-200 hover:shadow-glow-purple text-sm"
            >
              <CheckCircle className="w-4 h-4" />
              적용
            </button>
          </div>
          
          <textarea
            value={editableJson || rawJson}
            onChange={(e) => setEditableJson(e.target.value)}
            placeholder='{"film_id": "FILM_000001", ...}'
            className="flex-1 min-h-[400px] p-4 bg-bg-tertiary border border-border-color rounded-lg
                       font-mono text-sm text-text-primary resize-none
                       focus:outline-none focus:border-accent-purple focus:ring-1 focus:ring-accent-purple"
            spellCheck={false}
          />
        </div>
      )}
    </div>
  );
}
