import { ParseResult, ValidationError, Stage1JSON } from '../types/stage1.types';

/**
 * JSON 자동 수정 시도
 */
function autoFixJson(jsonString: string): { fixed: string; fixedCount: number; fixes: string[] } {
  let fixed = jsonString;
  const fixes: string[] = [];

  // 1. 후행 쉼표 제거: },] or ,]
  const trailingCommaPattern = /,(\s*[}\]])/g;
  if (trailingCommaPattern.test(fixed)) {
    fixed = fixed.replace(trailingCommaPattern, '$1');
    fixes.push('후행 쉼표(trailing comma) 제거');
  }

  // 2. 작은따옴표를 큰따옴표로 변환
  // 문자열 내부의 작은따옴표는 유지해야 하므로 주의
  const singleQuoteKeyPattern = /'([^']+)'(\s*:)/g;
  if (singleQuoteKeyPattern.test(fixed)) {
    fixed = fixed.replace(singleQuoteKeyPattern, '"$1"$2');
    fixes.push('작은따옴표를 큰따옴표로 변환 (키)');
  }

  // 3. "null" 문자열을 null로 변환
  const nullStringPattern = /:\s*"null"/g;
  if (nullStringPattern.test(fixed)) {
    fixed = fixed.replace(nullStringPattern, ': null');
    fixes.push('"null" 문자열을 null 값으로 변환');
  }

  // 4. 따옴표 없는 키에 따옴표 추가 (간단한 케이스만)
  const unquotedKeyPattern = /{\s*([a-zA-Z_][a-zA-Z0-9_]*)\s*:/g;
  if (unquotedKeyPattern.test(fixed)) {
    fixed = fixed.replace(unquotedKeyPattern, '{ "$1":');
    fixes.push('따옴표 없는 키에 따옴표 추가');
  }

  // 5. 주석 제거 (// 스타일)
  const commentPattern = /\/\/.*$/gm;
  if (commentPattern.test(fixed)) {
    fixed = fixed.replace(commentPattern, '');
    fixes.push('주석 제거');
  }

  return {
    fixed,
    fixedCount: fixes.length,
    fixes
  };
}

/**
 * JSON 문법 오류 위치 추출
 */
function extractErrorPosition(error: SyntaxError, jsonString: string): { line: number; column: number } | null {
  const match = error.message.match(/position (\d+)/);
  if (!match) return null;

  const position = parseInt(match[1], 10);
  const lines = jsonString.substring(0, position).split('\n');
  const line = lines.length;
  const column = lines[lines.length - 1].length + 1;

  return { line, column };
}

/**
 * JSON 파싱 및 검증
 */
export function parseAndValidateJson(jsonString: string): ParseResult {
  const errors: ValidationError[] = [];
  let autoFixedCount = 0;

  // 빈 문자열 체크
  if (!jsonString.trim()) {
    return {
      success: false,
      rawJson: jsonString,
      errors: [{
        level: 'syntax',
        severity: 'error',
        message: 'JSON이 비어있습니다.',
        autoFixable: false
      }],
      autoFixedCount: 0
    };
  }

  // 1차 파싱 시도
  try {
    const data = JSON.parse(jsonString) as Stage1JSON;
    return {
      success: true,
      data,
      rawJson: jsonString,
      errors: [],
      autoFixedCount: 0
    };
  } catch (firstError) {
    // 자동 수정 시도
    const { fixed, fixedCount, fixes } = autoFixJson(jsonString);
    autoFixedCount = fixedCount;

    if (fixedCount > 0) {
      try {
        const data = JSON.parse(fixed) as Stage1JSON;
        // 자동 수정 성공
        return {
          success: true,
          data,
          rawJson: fixed,
          errors: fixes.map(fix => ({
            level: 'syntax' as const,
            severity: 'warning' as const,
            message: `자동 수정됨: ${fix}`,
            autoFixable: true
          })),
          autoFixedCount
        };
      } catch {
        // 자동 수정 후에도 실패
      }
    }

    // 자동 수정 불가 - 오류 정보 생성
    const syntaxError = firstError as SyntaxError;
    const position = extractErrorPosition(syntaxError, jsonString);
    
    errors.push({
      level: 'syntax',
      severity: 'error',
      line: position?.line,
      message: syntaxError.message,
      suggestion: '괄호나 쉼표, 따옴표를 확인해주세요.',
      autoFixable: false
    });

    return {
      success: false,
      rawJson: jsonString,
      errors,
      autoFixedCount
    };
  }
}

/**
 * 스키마 검증
 */
export function validateSchema(data: Stage1JSON): ValidationError[] {
  const errors: ValidationError[] = [];

  // film_id 패턴 검증
  if (!/^FILM_\d{6}$/.test(data.film_id)) {
    errors.push({
      level: 'schema',
      severity: 'error',
      path: 'film_id',
      message: `film_id "${data.film_id}"가 패턴(FILM_XXXXXX)과 일치하지 않습니다.`,
      autoFixable: false
    });
  }

  // duration_minutes 범위 검증
  if (data.film_metadata.duration_minutes < 1 || data.film_metadata.duration_minutes > 15) {
    errors.push({
      level: 'schema',
      severity: 'warning',
      path: 'film_metadata.duration_minutes',
      message: `duration_minutes(${data.film_metadata.duration_minutes})가 권장 범위(1-15분)를 벗어났습니다.`,
      autoFixable: false
    });
  }

  // aspect_ratio 패턴 검증
  if (!/^\d+:\d+$/.test(data.film_metadata.aspect_ratio)) {
    errors.push({
      level: 'schema',
      severity: 'error',
      path: 'film_metadata.aspect_ratio',
      message: `aspect_ratio "${data.film_metadata.aspect_ratio}"가 패턴(N:N)과 일치하지 않습니다.`,
      autoFixable: false
    });
  }

  return errors;
}

/**
 * 구조 검증 (블록 수, ID 패턴 등)
 */
export function validateStructure(data: Stage1JSON): ValidationError[] {
  const errors: ValidationError[] = [];

  // visual_blocks가 있는 경우에만 검증
  if (!data.visual_blocks) {
    if (data.current_step === 'concept_art_blocks_completed') {
      errors.push({
        level: 'structure',
        severity: 'error',
        path: 'visual_blocks',
        message: 'current_step이 concept_art_blocks_completed이지만 visual_blocks가 없습니다.',
        autoFixable: false
      });
    }
    return errors;
  }

  // 캐릭터 검증
  data.visual_blocks.characters?.forEach((char, index) => {
    if (!/^CHAR_\d{3}(_[A-Z])?$/.test(char.id)) {
      errors.push({
        level: 'structure',
        severity: 'error',
        path: `visual_blocks.characters[${index}].id`,
        message: `캐릭터 ID "${char.id}"가 패턴(CHAR_XXX 또는 CHAR_XXX_A)과 일치하지 않습니다.`,
        autoFixable: false
      });
    }

    const blockCount = Object.keys(char.blocks || {}).length;
    if (blockCount !== 25) {
      errors.push({
        level: 'structure',
        severity: 'warning',
        path: `visual_blocks.characters[${index}].blocks`,
        message: `캐릭터 "${char.name}"의 블록 수가 ${blockCount}개입니다. (기대값: 25개)`,
        autoFixable: false
      });
    }
  });

  // 장소 검증
  data.visual_blocks.locations?.forEach((loc, index) => {
    if (!/^LOC_\d{3}$/.test(loc.id)) {
      errors.push({
        level: 'structure',
        severity: 'error',
        path: `visual_blocks.locations[${index}].id`,
        message: `장소 ID "${loc.id}"가 패턴(LOC_XXX)과 일치하지 않습니다.`,
        autoFixable: false
      });
    }

    const blockCount = Object.keys(loc.blocks || {}).length;
    if (blockCount !== 28) {
      errors.push({
        level: 'structure',
        severity: 'warning',
        path: `visual_blocks.locations[${index}].blocks`,
        message: `장소 "${loc.name}"의 블록 수가 ${blockCount}개입니다. (기대값: 28개)`,
        autoFixable: false
      });
    }
  });

  // 소품 검증
  data.visual_blocks.props?.forEach((prop, index) => {
    if (!/^PROP_\d{3}$/.test(prop.id)) {
      errors.push({
        level: 'structure',
        severity: 'error',
        path: `visual_blocks.props[${index}].id`,
        message: `소품 ID "${prop.id}"가 패턴(PROP_XXX)과 일치하지 않습니다.`,
        autoFixable: false
      });
    }

    const blockCount = Object.keys(prop.blocks || {}).length;
    if (blockCount !== 21) {
      errors.push({
        level: 'structure',
        severity: 'warning',
        path: `visual_blocks.props[${index}].blocks`,
        message: `소품 "${prop.name}"의 블록 수가 ${blockCount}개입니다. (기대값: 21개)`,
        autoFixable: false
      });
    }
  });

  // 씬 검증
  data.current_work.scenario?.scenes?.forEach((scene, index) => {
    if (!/^S\d{2}$/.test(scene.scene_id)) {
      errors.push({
        level: 'structure',
        severity: 'error',
        path: `current_work.scenario.scenes[${index}].scene_id`,
        message: `씬 ID "${scene.scene_id}"가 패턴(S00)과 일치하지 않습니다.`,
        autoFixable: false
      });
    }
  });

  return errors;
}

/**
 * 전체 검증 수행
 */
export function fullValidation(data: Stage1JSON): ValidationError[] {
  return [
    ...validateSchema(data),
    ...validateStructure(data)
  ];
}
