import { ValidationError, Scene, Character, Location, Prop, Block } from '../types/stage1.types';

/**
 * 문법 오류 프롬프트 생성
 */
export function generateSyntaxErrorPrompt(errors: ValidationError[], rawJson: string): string {
  const errorList = errors
    .filter(e => e.level === 'syntax' && e.severity === 'error')
    .map((e, i) => {
      const lineInfo = e.line ? `Line ${e.line}` : '위치 불명';
      return `${i + 1}. ${lineInfo}: ${e.message}`;
    })
    .join('\n');

  // 오류 주변 코드 추출 (첫 번째 오류 기준)
  const firstError = errors.find(e => e.line);
  let codeSnippet = '';
  
  if (firstError?.line) {
    const lines = rawJson.split('\n');
    const startLine = Math.max(0, firstError.line - 3);
    const endLine = Math.min(lines.length, firstError.line + 2);
    
    codeSnippet = lines
      .slice(startLine, endLine)
      .map((line, i) => {
        const lineNum = startLine + i + 1;
        const marker = lineNum === firstError.line ? ' → ' : '   ';
        return `${marker}${lineNum}: ${line}`;
      })
      .join('\n');
  }

  return `[Stage 1 JSON 오류 수정 요청]

■ 오류 유형: JSON 문법 오류

■ 오류 목록
${errorList}

${codeSnippet ? `■ 오류 주변 코드\n${codeSnippet}\n` : ''}
■ 요청
위 문법 오류를 수정하여 올바른 JSON을 다시 출력해주세요.
`.trim();
}

/**
 * 스키마/구조 오류 프롬프트 생성
 */
export function generateValidationErrorPrompt(errors: ValidationError[]): string {
  const grouped = {
    schema: errors.filter(e => e.level === 'schema'),
    structure: errors.filter(e => e.level === 'structure')
  };

  let content = `[Stage 1 JSON 검증 오류 수정 요청]\n\n`;

  if (grouped.schema.length > 0) {
    content += `■ 스키마 오류 (${grouped.schema.length}건)\n`;
    grouped.schema.forEach((e, i) => {
      const severity = e.severity === 'error' ? '❌' : '⚠️';
      content += `${i + 1}. ${severity} ${e.path}: ${e.message}\n`;
    });
    content += '\n';
  }

  if (grouped.structure.length > 0) {
    content += `■ 구조 오류 (${grouped.structure.length}건)\n`;
    grouped.structure.forEach((e, i) => {
      const severity = e.severity === 'error' ? '❌' : '⚠️';
      content += `${i + 1}. ${severity} ${e.path}: ${e.message}\n`;
    });
    content += '\n';
  }

  content += `■ 요청
위 오류를 수정하여 해당 섹션을 다시 출력해주세요.`;

  return content;
}

/**
 * 시나리오 수정 프롬프트 생성
 */
export function generateScenarioEditPrompt(
  scene: Scene,
  originalText: string,
  modifiedText: string,
  userRequest: string
): string {
  return `[Stage 1 시나리오 수정 요청]

■ 대상 씬
- 씬 번호: ${scene.scene_number} (${scene.scene_id})
- 시퀀스: ${scene.sequence_id}

■ 원본 시나리오
${originalText}

■ 수정된 시나리오
${modifiedText || '(수정 내용 없음)'}

■ 수정 요청사항
${userRequest || '(추가 요청 없음)'}

■ 요청
위 내용을 반영하여 해당 씬의 시나리오를 업데이트해주세요.
`.trim();
}

/**
 * 블록 수정 프롬프트 생성
 */
export function generateBlockEditPrompt(
  itemType: 'character' | 'location' | 'prop',
  item: Character | Location | Prop,
  originalBlocks: Block,
  modifiedBlocks: string,
  userRequest: string
): string {
  const typeKorean = {
    character: '캐릭터',
    location: '장소',
    prop: '소품'
  }[itemType];

  const originalBlocksFormatted = Object.entries(originalBlocks)
    .map(([key, value]) => `${key}: ${value}`)
    .join('\n');

  return `[Stage 1 ${typeKorean} 블록 수정 요청]

■ 대상 ${typeKorean}
- ID: ${item.id}
- 이름: ${item.name}

■ 원본 블록
${originalBlocksFormatted}

■ 수정된 블록
${modifiedBlocks || '(수정 내용 없음)'}

■ 수정 요청사항
${userRequest || '(추가 요청 없음)'}

■ 요청
위 내용을 반영하여 해당 ${typeKorean}의 블록을 업데이트해주세요.
관련된 다른 필드(character_detail, prop_detail 등)도 필요시 함께 수정해주세요.
`.trim();
}

/**
 * 클립보드에 복사
 */
export async function copyToClipboard(text: string): Promise<boolean> {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch {
    // 폴백: execCommand 사용
    const textarea = document.createElement('textarea');
    textarea.value = text;
    textarea.style.position = 'fixed';
    textarea.style.opacity = '0';
    document.body.appendChild(textarea);
    textarea.select();
    
    try {
      document.execCommand('copy');
      return true;
    } catch {
      return false;
    } finally {
      document.body.removeChild(textarea);
    }
  }
}
