import { useState, useRef, useCallback } from 'react';
import { Header } from './components/Layout/Header';
import { Sidebar } from './components/Layout/Sidebar';
import { JsonInput } from './components/Input/JsonInput';
import { MetadataView } from './components/Viewer/MetadataView';
import { SynopsisView } from './components/Viewer/SynopsisView';
import { TreatmentView } from './components/Viewer/TreatmentView';
import { ScenarioView } from './components/Viewer/ScenarioView';
import { ConceptArtView } from './components/Viewer/ConceptArtView';
import { parseAndValidateJson, fullValidation } from './utils/jsonParser';
import { Stage1JSON, ActiveSection, ValidationError, ViewState } from './types/stage1.types';

function App() {
  const [viewState, setViewState] = useState<ViewState>('empty');
  const [jsonData, setJsonData] = useState<Stage1JSON | null>(null);
  const [rawJson, setRawJson] = useState('');
  const [errors, setErrors] = useState<ValidationError[]>([]);
  const [autoFixedCount, setAutoFixedCount] = useState(0);
  const [activeSection, setActiveSection] = useState<ActiveSection>('metadata');
  const [fileName, setFileName] = useState<string | undefined>();
  const fileInputRef = useRef<HTMLInputElement>(null);

  // 활성화된 섹션 계산
  const getEnabledSections = useCallback((): ActiveSection[] => {
    if (!jsonData) return [];
    
    const step = jsonData.current_step;
    const sections: ActiveSection[] = ['metadata'];
    
    if (step === 'logline_synopsis_development' || step === 'treatment_expansion' || 
        step === 'scenario_development' || step === 'concept_art_blocks_completed') {
      sections.push('synopsis');
    }
    
    if (step === 'treatment_expansion' || step === 'scenario_development' || 
        step === 'concept_art_blocks_completed') {
      sections.push('treatment');
    }
    
    if (step === 'scenario_development' || step === 'concept_art_blocks_completed') {
      sections.push('scenario');
    }
    
    if (step === 'concept_art_blocks_completed' && jsonData.visual_blocks) {
      sections.push('characters', 'locations', 'props');
    }
    
    return sections;
  }, [jsonData]);

  // JSON 파싱 처리
  const handleJsonParsed = useCallback((jsonString: string) => {
    setViewState('loading');
    setRawJson(jsonString);

    // 약간의 딜레이 (UX용)
    setTimeout(() => {
      const result = parseAndValidateJson(jsonString);
      setAutoFixedCount(result.autoFixedCount);

      if (!result.success) {
        setErrors(result.errors);
        setViewState('syntax-error');
        setJsonData(null);
        return;
      }

      // 파싱 성공 - 추가 검증
      const validationErrors = fullValidation(result.data!);
      const allErrors = [...result.errors, ...validationErrors];
      
      setJsonData(result.data!);
      setErrors(allErrors);
      setRawJson(result.rawJson || jsonString);

      if (allErrors.some(e => e.severity === 'error')) {
        setViewState('error');
      } else if (result.data!.current_step === 'concept_art_blocks_completed') {
        setViewState('complete');
      } else {
        setViewState('partial');
      }
    }, 100);
  }, []);

  // 파일 업로드 처리
  const handleUpload = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setFileName(file.name);
      const reader = new FileReader();
      reader.onload = (event) => {
        const content = event.target?.result as string;
        handleJsonParsed(content);
      };
      reader.readAsText(file);
    }
  };

  // 리셋 처리
  const handleReset = () => {
    setViewState('empty');
    setJsonData(null);
    setRawJson('');
    setErrors([]);
    setAutoFixedCount(0);
    setActiveSection('metadata');
    setFileName(undefined);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  // JSON 다운로드
  const handleDownload = () => {
    if (!rawJson) return;
    
    const blob = new Blob([rawJson], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = fileName || `${jsonData?.film_id || 'stage1'}_clean.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  // 현재 섹션 렌더링
  const renderContent = () => {
    if (viewState === 'empty') {
      return (
        <JsonInput
          onJsonParsed={handleJsonParsed}
          errors={[]}
          rawJson=""
          autoFixedCount={0}
        />
      );
    }

    if (viewState === 'loading') {
      return (
        <div className="flex-1 flex items-center justify-center">
          <div className="flex flex-col items-center gap-4">
            <div className="w-12 h-12 border-4 border-accent-purple border-t-transparent rounded-full animate-spin" />
            <p className="text-text-secondary">Parsing...</p>
          </div>
        </div>
      );
    }

    if (viewState === 'syntax-error') {
      return (
        <JsonInput
          onJsonParsed={handleJsonParsed}
          errors={errors}
          rawJson={rawJson}
          autoFixedCount={autoFixedCount}
        />
      );
    }

    if (!jsonData) return null;

    switch (activeSection) {
      case 'metadata':
        return (
          <MetadataView
            filmId={jsonData.film_id}
            currentStep={jsonData.current_step}
            timestamp={jsonData.timestamp}
            metadata={jsonData.film_metadata}
          />
        );
      case 'synopsis':
        return (
          <SynopsisView
            logline={jsonData.current_work.logline}
            synopsis={jsonData.current_work.synopsis}
          />
        );
      case 'treatment':
        return (
          <TreatmentView treatment={jsonData.current_work.treatment} />
        );
      case 'scenario':
        return (
          <ScenarioView
            title={jsonData.current_work.scenario?.title || ''}
            scenes={jsonData.current_work.scenario?.scenes || []}
          />
        );
      case 'characters':
        return (
          <ConceptArtView
            type="character"
            items={jsonData.visual_blocks?.characters || []}
          />
        );
      case 'locations':
        return (
          <ConceptArtView
            type="location"
            items={jsonData.visual_blocks?.locations || []}
          />
        );
      case 'props':
        return (
          <ConceptArtView
            type="prop"
            items={jsonData.visual_blocks?.props || []}
          />
        );
      default:
        return null;
    }
  };

  const enabledSections = getEnabledSections();
  const hasData = viewState !== 'empty' && viewState !== 'loading';

  return (
    <div className="h-screen flex flex-col bg-bg-primary">
      <Header
        onUpload={handleUpload}
        onReset={handleReset}
        onDownload={handleDownload}
        hasData={hasData && !!jsonData}
        fileName={fileName}
      />
      
      <div className="flex-1 flex overflow-hidden">
        {hasData && jsonData && (
          <Sidebar
            activeSection={activeSection}
            onSectionChange={setActiveSection}
            enabledSections={enabledSections}
            errors={errors}
          />
        )}
        
        <main className="flex-1 flex overflow-hidden">
          {renderContent()}
        </main>
      </div>

      {/* 숨겨진 파일 입력 */}
      <input
        ref={fileInputRef}
        type="file"
        accept=".json"
        onChange={handleFileChange}
        className="hidden"
      />
    </div>
  );
}

export default App;
