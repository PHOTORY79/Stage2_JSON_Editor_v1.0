// Stage 1 JSON 타입 정의

export interface FilmMetadata {
  title_working: string;
  genre: string;
  duration_minutes: number;
  style: string;
  artist: string | null;
  medium: string;
  era: string;
  aspect_ratio: string;
}

export interface Synopsis {
  act1: string;
  act2: string;
  act3: string;
}

export interface Sequence {
  sequence_id: string;
  sequence_title: string;
  act: string;
  dramatic_function: string;
  content: string;
}

export interface Treatment {
  title: string;
  structure: string;
  sequences: Sequence[];
}

export interface Scene {
  scene_number: number;
  scene_id: string;
  sequence_id: string;
  scenario_text: string;
}

export interface Scenario {
  title: string;
  scenes: Scene[];
}

export interface Block {
  [key: string]: string;
}

export interface Character {
  id: string;
  name: string;
  character_detail: string;
  voice_style: string;
  blocks: Block;
}

export interface Location {
  id: string;
  name: string;
  blocks: Block;
}

export interface Prop {
  id: string;
  name: string;
  prop_detail: string;
  blocks: Block;
}

export interface VisualBlocks {
  characters: Character[];
  locations: Location[];
  props: Prop[];
}

export interface CurrentWork {
  logline: string;
  synopsis: Synopsis;
  treatment: Treatment;
  scenario: Scenario;
}

export interface Stage1JSON {
  film_id: string;
  current_step: 'logline_synopsis_development' | 'treatment_expansion' | 'scenario_development' | 'concept_art_blocks_completed';
  timestamp: string;
  film_metadata: FilmMetadata;
  current_work: CurrentWork;
  visual_blocks?: VisualBlocks;
}

// 검증 관련 타입
export type ErrorLevel = 'syntax' | 'schema' | 'structure';
export type ErrorSeverity = 'error' | 'warning';

export interface ValidationError {
  level: ErrorLevel;
  severity: ErrorSeverity;
  line?: number;
  path?: string;
  message: string;
  suggestion?: string;
  autoFixable: boolean;
}

export interface ParseResult {
  success: boolean;
  data?: Stage1JSON;
  rawJson?: string;
  errors: ValidationError[];
  autoFixedCount: number;
}

// UI 상태 타입
export type ViewState = 'empty' | 'loading' | 'syntax-error' | 'partial' | 'complete' | 'error';
export type ActiveSection = 'metadata' | 'synopsis' | 'treatment' | 'scenario' | 'characters' | 'locations' | 'props';
